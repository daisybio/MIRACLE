rppa.filter.diameter <-
function(spots)
{
  spots$Signal[spots$Diameter >= 250] <- NA
  return(spots)
}
