rppa.filter.flagged <-
function(spots)
{
  spots$Signal[spots$Flag != 0] <- NA
  return(spots)
}
