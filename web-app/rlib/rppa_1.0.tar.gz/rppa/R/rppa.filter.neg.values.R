rppa.filter.neg.values <-
function(spots)
{
  spots$Signal[(spots$FG-spots$BG <= 0)] <- NA
  return(spots)
}
