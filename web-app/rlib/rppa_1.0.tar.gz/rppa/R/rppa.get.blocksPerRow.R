rppa.get.blocksPerRow <-
function(spots)
{
  attr(spots, "blocksPerRow")
}
