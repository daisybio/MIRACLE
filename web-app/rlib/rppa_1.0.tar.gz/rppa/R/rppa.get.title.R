rppa.get.title <-
function(spots)
{
  attr(spots, "title")
}
