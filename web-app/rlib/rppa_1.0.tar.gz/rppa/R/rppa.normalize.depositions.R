rppa.normalize.depositions <-
function(data.protein.conc)
{
  data.protein.conc <- within(data.protein.conc, {
    x.weighted.mean <- x.weighted.mean / as.numeric(Deposition)
    x.err <- x.err / as.numeric(Deposition)
  })
  
  return(data.protein.conc)
}
