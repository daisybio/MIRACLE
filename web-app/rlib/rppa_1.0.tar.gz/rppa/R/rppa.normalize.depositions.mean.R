rppa.normalize.depositions.mean <-
function(data.protein.conc)
{
  require(plyr)
  
  depos.means <- ddply(subset(data.protein.conc, select=c("x.weighted.mean", "Deposition")), .(Deposition), summarise, deposition.mean = mean(x.weighted.mean))  
  
  data.protein.conc <- merge(data.protein.conc, depos.means)
  
  data.protein.conc <- within(data.protein.conc, {
    x.weighted.mean <- x.weighted.mean / deposition.mean
    x.err <- x.err / as.numeric(deposition.mean)
  })
  
  return(data.protein.conc)
}
