rppa.normalize.to.ref.sample <-
function(data.protein.conc, sampleReference, each.A=F, each.B=F, specific.A, specific.B, method="mean")
{
  require(plyr)
  
  toRefSample <- function(data.protein.conc){ 
    if(is.null(specific.A) && is.null(specific.B)) my.subset <- subset(data.protein.conc, Sample == sampleReference)
    else if(is.null(specific.B)){
      if(!is.na(specific.A)) my.subset <- subset(data.protein.conc, Sample == sampleReference & A == specific.A)
      else my.subset <- subset(data.protein.conc, Sample == sampleReference & is.na(A))
    } 
    else if(is.null(specific.A)){
      if(!is.na(specific.B)) my.subset <- subset(data.protein.conc, Sample == sampleReference & B == specific.B)
      else  my.subset <- subset(data.protein.conc, Sample == sampleReference & is.na(B))
    } 
    else{
      if(!is.na(specific.A) && !is.na(specific.B)) my.subset <- subset(data.protein.conc, Sample == sampleReference & A == specific.A & B == specific.B)
      else if(is.na(specific.A) & !is.na(specific.B)) my.subset <- subset(data.protein.conc, Sample == sampleReference & B == specific.B & is.na(A))
      else if(is.na(specific.B) & !is.na(specific.A)) my.subset <- subset(data.protein.conc, Sample == sampleReference & A == specific.A & is.na(B))
      else my.subset <- subset(data.protein.conc, Sample == sampleReference & is.na(A) & is.na(B))  
    } 
       
    if(method == "mean")  meanOfRefSample <- mean(my.subset$x.weighted.mean, na.rm=T)
    else if(method == "mean")  meanOfRefSample <- median(my.subset$x.weighted.mean, na.rm=T)
       
    data.protein.conc <- within(data.protein.conc, {
      x.weighted.mean <- x.weighted.mean / meanOfRefSample  
      x.err <- x.err / meanOfRefSample
    }, meanOfRefSample=meanOfRefSample)
  }
  
  if(each.A && each.B){  
    data.protein.conc <- ddply(data.protein.conc, .(A, B), toRefSample)
  }
  else if(each.A){
    data.protein.conc <- ddply(data.protein.conc, .(A), toRefSample)
  }
  else if(each.B){
    data.protein.conc <- ddply(data.protein.conc, .(B), toRefSample)
  }
  else 
  {
    data.protein.conc <- toRefSample(data.protein.conc)
  }
  
  return(data.protein.conc)
}
