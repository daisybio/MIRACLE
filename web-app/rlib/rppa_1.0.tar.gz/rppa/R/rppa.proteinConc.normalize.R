rppa.proteinConc.normalize <-
function(slideA, slideB, normalize.with.median.first = T, normalize.per.deposition=T, output.all=F)
{   
  sub.normalize <- function(slideA){
    slideA$x.err <- slideA$x.err / median(slideA$x.weighted.mean, na.rm=T)
    slideA$x.weighted.mean <- slideA$x.weighted.mean / median(slideA$x.weighted.mean, na.rm=T)
    return(slideA)
  }
  
  if(normalize.with.median.first)
  {
    if(!normalize.per.deposition){
      slideA <- sub.normalize(slideA)
      slideB <- sub.normalize(slideB)
    }
    else{
      slideA <- ddply(slideA, .(Deposition), sub.normalize)
      slideB <- ddply(slideB, .(Deposition), sub.normalize)
    }
  }
  
  result <- slideA
  result$x.weighted.mean <- slideA$x.weighted.mean / slideB$x.weighted.mean
  #calculate percentage error, build sum and calculate real error on the new value.
  result$x.err <- (( slideA$x.err /slideA$x.weighted.mean ) + ( slideB$x.err / slideB$x.weighted.mean )) * result$x.weighted.mean
  
  result$Slide <- paste(slideA$Slide, "normalized by", slideB$Slide)
  if(output.all) result <- rbind(slideA, result, slideB)
    
  return(result)
}
