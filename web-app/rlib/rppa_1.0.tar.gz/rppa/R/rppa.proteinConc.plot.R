rppa.proteinConc.plot <-
function(data.protein.conc, title="", swap=F, horizontal.line=T, error.bars=T){
  
  require(ggplot2)
  require(gridExtra)
  
  #check if data has been summarized
  if(is.null(data.protein.conc$Sample))
  {
    return("You have to summarize the data before you can plot it! rppa.proteinConc.summarize()")
  }
  
  #plot protein concentrations  
  limits <- aes(ymax = x.weighted.mean + x.err, ymin= x.weighted.mean - x.err)
  dodge <- position_dodge(width=0.9)
  
  if(!is.null(data.protein.conc$Deposition)){  
      p <- qplot(Sample, x.weighted.mean, data=data.protein.conc, 
                 main=title, 
                 ylab="Estimated Protein Concentration (Relative Scale)",xlab="Sample", geom="bar", fill=Deposition, position="dodge")
  }
  else if(!is.null(data.protein.conc$Fill))
  {
    p <- qplot(Sample, x.weighted.mean, data=data.protein.conc, 
               main=title, 
               ylab="Estimated Protein Concentration (Relative Scale)",xlab="Sample", geom="bar", fill=Fill, position="dodge")   
    p <- p + guides(fill=guide_legend(title=NULL))
  }
  else { 
      p <- qplot(Sample, x.weighted.mean, data=data.protein.conc, 
                 main=title, 
                 ylab="Estimated Protein Concentration (Relative Scale)",xlab="Sample", geom="bar")
  }
  
  if(!is.null(data.protein.conc$B) && !is.null(data.protein.conc$A)){
    if(swap) p <- p + facet_grid(B~A)
    else p <- p + facet_grid(A~B)
  }
  
  else if(!is.null(data.protein.conc$A))
    p <- p + facet_wrap(~A)
  
  else if(!is.null(data.protein.conc$B))
    p <- p + facet_wrap(~B)
  
  if(error.bars) p <- p + geom_errorbar(limits, width=0.25, position=dodge)
  
  if(horizontal.line)  p <- p + geom_hline(aes(yintercept=1))
  
  p <- p + opts(axis.text.x = theme_text(angle=-45, hjust=0, vjust=1))
  p <- p + opts(plot.margin = unit(c(1,2,1,1), "cm"))
  
  print(p)
}
