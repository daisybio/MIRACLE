rppa.serialDilution <-
function(spots, initial.dilution.estimate=2, sensible.min=5, sensible.max=6.e5, compress.results=T, ...)
{ 
  #convert input table so that each dilution is in one column
  spots.c <- rppa.serialDilution.format(spots)
  
  #extract number of different dilutions that are not NA
  numOfDilutions <- length(unique(spots$DilutionFactor[!is.na(spots$DilutionFactor)]))
  
  #calculate matrix of dilutions
  spots.m <- rppa.serialDilution.dilutionMatrix(spots.c, numOfDilutions)
  
  #compute the actual protein estimates using the serial dilution method
  spots.e <- rppa.serialDilution.compute(spots.m, initial.dilution.estimate, sensible.min, sensible.max)
  
  #combine estimates with signal information
  spots.result <- cbind(spots.c[,1:(ncol(spots.c)-numOfDilutions)], spots.e)
  
  if(!compress.results) return(spots.result)
  
  spots.summarize <- rppa.proteinConc.summarize(spots.result, ...)
  
  return(spots.summarize)
}
