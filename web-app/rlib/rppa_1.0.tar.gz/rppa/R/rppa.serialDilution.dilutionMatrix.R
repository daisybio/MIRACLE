rppa.serialDilution.dilutionMatrix <-
function(spots.c, numOfDilutions)
{  
  #extract dilution matrix for serial dilution curve algorithm
  spots.m <- as.matrix(spots.c[,(ncol(spots.c)-(numOfDilutions-1)):ncol(spots.c)] )
  
  return(spots.m)
}
