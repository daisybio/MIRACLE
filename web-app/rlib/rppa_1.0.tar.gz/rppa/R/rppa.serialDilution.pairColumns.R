rppa.serialDilution.pairColumns <-
function(spots, startColumn=1){
  
  pairedData <- data.frame(x=numeric(0), y=numeric(0))
  
  for(i in startColumn:(ncol(spots)-1))
  {
    pairedData <- rbind(pairedData, cbind(x=spots[,i+1], y=spots[,i]))  
  }
  
  return(pairedData)
  
}
