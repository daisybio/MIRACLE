rppa.superCurve <- function(spots, select.columns.sample=c("CellLine"), 
                            select.columns.A="LysisBuffer", select.columns.B="Inducer", 
                            select.columns.fill="Treatment", return.fit.only=F, model="logistic", method="nlrob", ci=T, interactive=T){
  
  require(limma)
  require(SuperCurve)
  
  #check for necessary attributes title, antibody, 
  if(is.null(attr(spots, "title"))) return("Please set attribute 'title' first!")
  if(is.null(attr(spots, "antibody"))) return("Please set attribute 'antibody' first!")
  if(is.null(attr(spots, "blocksPerRow")))return("Please set attribute 'blocksPerRow' first!")
  
  #correct inducer format
  if(length(unique(spots$Inducer)) > 1)
    spots$Inducer <- gsub(" [0-9]+[.][0-9] mM", "", spots$Inducer )
  
  #correct dilution factors
  spots$DilutionFactor <- as.double(spots$DilutionFactor)
  
  #create data object for SuperCurve package  
  
  #create sample name from all selected columns  
  Sample <- rppa.superCurve.create.sample.names(spots, select.columns.sample, select.columns.A, select.columns.B, select.columns.fill)
  parsedData <- rppa.superCurve.parse.data(Sample, spots)
  
  #put the information in a RPPA data object
  new.rppa <- rppa.superCurve.create.rppa(parsedData, spots)
  
  #we need the dilution factors as log2 to a reference point, which we will choose to be undiluted 1.0
  steps <- round(log2(spots$DilutionFactor)) + log2(spots$Deposition)
  #steps[is.na(steps)] <- 0
  
  series <- rppa.superCurve.create.series(parsedData, spots)
  
  new.design <- RPPADesign(new.rppa, steps=steps, series=new.rppa@data$Sample, controls=c("Control"), center=T)
  
  if(interactive){
    image(new.design)
    cat("Here you can see the dilution steps that are assumed to be correct. Press enter to continue.")
    readline()
  }
  
  new.fit <- RPPAFit(new.rppa, new.design, "Mean.Net", ci=ci, method=method, model=model)
  if(return.fit.only) return(new.fit)
  
  plot(new.fit)

  new.df <- rppa.superCurve.create.df(new.fit, select.columns.A, select.columns.B, select.columns.fill)
  #new.df$Slide <- attr(spots, "title")
  
  return(new.df)
}