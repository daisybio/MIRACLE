rppa.superCurve.create.series <-
function(parsed.data, spots)
{
  #we also need to assign dilution series, for now based on depositions
  series <- parsed.data[,c("Main.Row", "Main.Col", "Sub.Col", "Sub.Row")]
  
  #assuming four different individual dilution series in one block top: left/right, bottom: left/right 
  series$Sub.Col <- series$Sub.Col %/% ((max(series$Sub.Col) / 2)+1)
  series$Sub.Row <- series$Sub.Row %/% ((max(series$Sub.Row) / 2)+1)
  
  series <- apply(series, 1, paste, collapse=" ")
  series <- as.factor(series)
  
  return(series)
}
