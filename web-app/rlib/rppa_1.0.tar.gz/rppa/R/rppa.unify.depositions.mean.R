rppa.unify.depositions.mean <-
function(data.protein.conc){
  require(plyr)
  
  if(!is.null(data.protein.conc$A) && !is.null(data.protein.conc$B))
    data.protein.conc <- ddply(data.protein.conc, .(Sample, A, B, Fill), summarize, x.weighted.mean=mean(x.weighted.mean), x.err=mean(x.err))
  
  else if(!is.null(data.protein.conc$A))
    data.protein.conc <- ddply(data.protein.conc, .(Sample, A, Fill), summarize, x.weighted.mean=mean(x.weighted.mean), x.err=mean(x.err))
  
  else if(!is.null(data.protein.conc$B))
    data.protein.conc <- ddply(data.protein.conc, .(Sample, B, Fill), summarize, x.weighted.mean=mean(x.weighted.mean), x.err=mean(x.err))
  
  else data.protein.conc <- ddply(data.protein.conc, .(Sample, Fill), summarize, x.weighted.mean=mean(x.weighted.mean), x.err=mean(x.err))
  
  return(data.protein.conc)
}
